// +build windows

package gost

func kcpSigHandler() {}
