#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: linxiao
# | Date: 2021/4/21 
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   宝塔网站监控报表 - 更新补丁
# +--------------------------------------------------------------------
from __future__ import absolute_import, print_function, division
import datetime
import os
import sys
import time
import json
import re

os.chdir("/www/server/panel")
sys.path.insert(0, "/www/server/panel/class")

import public
from tsqlite import tsqlite
from lua_maker import LuaMaker

def get_log_db_path(site):
    db_path = os.path.join("/www/server/total", "logs/{}/logs.db".format(site))
    return db_path

keep_indexes = ['id_inx', 'time_inx']
migrating_file = "/www/server/total/migrating"

def check_database():
    try:
        print("开始优化数据存储结构，优化后每个站点每天将减少26%~30%的磁盘占用空间。")
        print("可能会耗费较长时间(与数据量、站点数量相关)，请耐心等待。")
        public.writeFile(migrating_file, "migrating")
        sites = public.M('sites').field('name').order("addtime").select()
        for site_info in sites:
            site = site_info["name"]
            print("校验站点:{}".format(site))
            db_path = get_log_db_path(site)
            if not os.path.isfile(db_path):
                continue
            ts = tsqlite()
            ts.dbfile(db_path)
            indexes = ts.query("select name from sqlite_master where type='index';")
            tips = {
                "ip": "IP",
                "uri": "URL",
                "status_code": "状态码",
                "method": "请求方法"
            }
            drop = False
            for arr in indexes:
                index = arr[0]
                if index not in keep_indexes:
                    drop = True
                    print("正在优化{}数据存储...".format(tips[index[0:index.find("_inx")]]))
                    start = time.time()
                    ts.execute("DROP INDEX " + index)
                    end = time.time()
                    diff = end-start
                    if diff > 59:
                        print("已完成，耗时:{}分{}秒".format(int(diff/60), round(diff%60)))
                    else:
                        print("已完成，耗时:{}秒".format(round(diff)))
            if drop:
                print("站点:{}已优化完成，未来新增数据将减少30%左右的存储空间。".format(site))
            # ts.execute("VACUUM;")
        print("数据存储结构优化完成！")
                # print(columns)
    except Exception as e:
        print(str(e))
        pass
    finally:
        if os.path.isfile(migrating_file):
            os.remove(migrating_file)

keep_columns = {
    "request_stat":["time", "req", "pv", "uv", "ip", "length", "spider"],
    "site_logs": ["is_spider", "request_headers"],
    "client_stat": ["other"]
}
keep_columns_info = {
    "request_headers": "request_headers TEXT DEFAULT ''",
    "spider": "spider INTEGER DEFAULT 0",
    "is_spider": "is_spider INTEGER DEFAULT 0",
    "other": "other INTEGER DEFAULT 0",
}
status_code_50x = [500, 501, 502, 503, 504, 505, 506, 507, 509, 510]
status_code_40x = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409,
                   410, 411, 412, 413, 414, 415, 416, 417, 418, 421, 
                   422, 423, 424, 425, 426, 449, 451]
http_methods = ["get", "post", "put", "patch", "delete"]

# 添加状态列
for s in status_code_50x:
    column = "status_"+repr(s)
    keep_columns["request_stat"].append(column)
    keep_columns_info.update({column: column + " INTEGER DEFAULT 0"})

for s in status_code_40x:
    column = "status_"+repr(s)
    keep_columns["request_stat"].append(column)
    keep_columns_info.update({column: column + " INTEGER DEFAULT 0"})

# 添加请求方法列
for method in http_methods:
    column = "http_"+method
    keep_columns["request_stat"].append(column)
    keep_columns_info.update({column: column+" INTEGER DEFAULT 0"})

def get_timestamp_interval(local_time):
    start = None
    end = None
    start = time.mktime((local_time.tm_year, local_time.tm_mon, local_time.tm_mday, 0, 0, 0, 0, 0, 0))
    end = time.mktime((local_time.tm_year, local_time.tm_mon, local_time.tm_mday, 23, 59, 59, 0, 0, 0))
    return start, end

def get_last_days_by_timestamp(day):
    now = time.localtime()
    t1 = time.mktime((now.tm_year, now.tm_mon, now.tm_mday - day + 1, 0, 0, 0, 0, 0, 0))
    t2 = time.localtime(t1)
    start, _ = get_timestamp_interval(t2)
    _, end = get_timestamp_interval(now)
    return start, end

def get_time_interval(local_time):
    start = None
    end = None
    time_key_format = "%Y%m%d00"
    start = int(time.strftime(time_key_format, local_time))
    time_key_format = "%Y%m%d23"
    end = int(time.strftime(time_key_format, local_time))
    return start, end

def get_last_days(day):
    now = time.localtime()
    t1 = time.mktime((now.tm_year, now.tm_mon, now.tm_mday - day + 1, 0, 0, 0, 0, 0, 0))
    t2 = time.localtime(t1)
    start, _ = get_time_interval(t2)
    _, end = get_time_interval(now)
    return start, end

sync_logs = {}
def mark_sync(site, item):
    log_path = "/www/server/panel/plugin/total/sync.log"
    key = site+"_"+item
    origin_content = ""
    if os.path.isfile(log_path):
        origin_content = public.readFile(log_path)
    public.writeFile(log_path, origin_content + key+"\n")
    sync_logs[key] = True

def is_synced(site, item):
    log_path = "/www/server/panel/plugin/total/sync.log"
    if not os.path.isfile(log_path):
        return False
    if not sync_logs:
        lines = public.readFile(log_path)
        if lines:
            lines = lines.split("\n")
            for line in lines:
                sync_logs[line.strip()] = True
    key = site+"_"+item
    if key in sync_logs.keys():
        return True
    return False    

def alter_columns():
    try:
        ts = None
        conn = None
        print("正在同步数据...")
        print("可能会耗费较长时间(与数据量、站点数量相关)，请耐心等待。")
        sites = public.M('sites').field('name').order("addtime").select()
        for site_info in sites:
            public.writeFile(migrating_file, "migrating")
            site = site_info["name"]
            # if site != "www.163.com":
            #     continue
            print("正在同步站点:{}".format(site))
            db_path = get_log_db_path(site)
            if not os.path.isfile(db_path):
                continue
            # ts = tsqlite()
            # ts.dbfile(db_path)
            import sqlite3
            conn = sqlite3.connect(db_path)
            ts = conn.cursor()
            has_sync_action = False
            conn.execute("BEGIN TRANSACTION;")
        
            for table_name, kcolumns in keep_columns.items():
                columns = ts.execute("PRAGMA table_info([{}])".format(table_name))
                columns = [column[1] for column in columns]
                for column_name in kcolumns:
                    if column_name not in columns:
                        # print("检查列:"+column_name)
                        if column_name in keep_columns_info.keys():
                            column_info = keep_columns_info[column_name]
                            alter_sql = "ALTER TABLE {} ADD COLUMN {};".format(table_name, column_info)
                            ts.execute(alter_sql)
                            has_sync_action = True

            if not is_synced(site, "spider"): 
                #spider
                start, end = get_last_days(30)
                spiders = ts.execute("PRAGMA table_info([{}])".format("spider_stat"))
                fields = ""
                for s in spiders:
                    if s[1] == "time": continue
                    if fields:
                        fields += "+"
                    fields += s[1]
                sync_sql = "select sum({}) as total, time from spider_stat where time between {} and {} group by time;"
                sync_sql = sync_sql.format(fields, start, end)
                # print("sync spider:" + sync_sql)
                spider_data = ts.execute(sync_sql).fetchall()
                for data in spider_data:
                    total = data[0]
                    time_key = data[1]
                    # print(total, time_key)
                    insert_sql = "INSERT INTO request_stat(time) SELECT {time_key} WHERE NOT EXISTS(SELECT time FROM request_stat WHERE time={time_key});".format(time_key=time_key)
                    ts.execute(insert_sql)
                    ts.execute("UPDATE request_stat set {column}={column}+{total} where time={time_key}".format(column="spider", total=total, time_key=time_key))
                mark_sync(site, "spider")
                has_sync_action = True
                
            if not is_synced(site, "status_code"):
                #50x
                start, end = get_last_days_by_timestamp(30)
                status_codes = ",".join([str(status) for status in status_code_50x+status_code_40x])
                # print("status codes:" + status_codes)
                sync_sql = "select status_code, strftime('%Y%m%d%H', datetime(time, 'unixepoch')) as time1, count(*) from site_logs where time between {} and {} and status_code in ({}) group by time1, status_code"
                # print("sync 50x:" +sync_sql.format(start, end))
                data_status = ts.execute(sync_sql.format(start, end, status_codes)).fetchall()
                # print(len(data_500))
                total_data = {}
                for data in data_status:
                    status_code = int(data[0])
                    time_key = data[1]
                    count = data[2]
                    if time_key not in total_data.keys():
                        total_data[time_key] = {}
                    if status_code not in total_data[time_key].keys():
                        total_data[time_key][status_code] = count
                
                # print("total data:")
                # print(total_data)
                
                for time_key, values in total_data.items():
                    insert_sql = "INSERT INTO request_stat(time) SELECT {time_key} WHERE NOT EXISTS(SELECT time FROM request_stat WHERE time={time_key});".format(time_key=time_key)
                    ts.execute(insert_sql)
                    fields = ""
                    for status, count in values.items():
                        if fields: fields += ","
                        fields += "status_" + repr(status) + "=" + "status_" + repr(status) +"+"+repr(count)
                        
                    ts.execute("UPDATE request_stat set {fields} where time={time_key}".format(fields=fields, time_key=time_key))
                mark_sync(site, "status_code")
                has_sync_action = True

            if not is_synced(site, "http_method"):
                
                start, end = get_last_days_by_timestamp(30)
                method_conditions = ""
                for m in http_methods:
                    if method_conditions: method_conditions += ","
                    method_conditions += "\'" +m.upper() +"\'"

                # print("condition:" + method_conditions)
                sync_sql = "select method, strftime('%Y%m%d%H', datetime(time, 'unixepoch')) as time1, count(*) from site_logs where time between {} and {} and method in ({}) group by time1, method"
                sync_sql = sync_sql.format(start, end, method_conditions)
                # print(sync_sql)
                results = ts.execute(sync_sql).fetchall()
                method_data = {}
                for data in results:
                    method = data[0].lower()
                    time_key = str(data[1])
                    count = data[2]
                    if time_key not in method_data.keys():
                        method_data[time_key] = {}
                    if method not in method_data[time_key].keys():
                        method_data[time_key][method] = count

                # print("method data")
                # print(method_data)

                for time_key, values in method_data.items():
                    insert_sql = "INSERT INTO request_stat(time) SELECT {time_key} WHERE NOT EXISTS(SELECT time FROM request_stat WHERE time={time_key});".format(time_key=time_key)
                    ts.execute(insert_sql)
                    fields = ""
                    for method, count in values.items():
                        if fields: fields += ","
                        fields += "http_" + method + "=" + "http_" + method +"+"+repr(count)
                    ts.execute("UPDATE request_stat set {fields} where time={time_key}".format(fields=fields, time_key=time_key))

                mark_sync(site, "http_method")
                has_sync_action = True

            try:
                conn.execute("COMMIT;")
            except Exception as e:
                err_msg = str(e)
                if err_msg.find("no transaction is active") < 0:
                    print(e)

            if has_sync_action:
                time.sleep(1)
            if os.path.isfile(migrating_file):
                os.remove(migrating_file)
            print("数据同步完成。")
    except RuntimeError as e:
        print(e)
        pass
    finally:
        if os.path.isfile(migrating_file):
            os.remove(migrating_file)
        try:
            if ts:
                ts.close()
            if conn:
                conn.close()
        except:
            pass

def write_site_domains():
    sites = public.M('sites').field('name,id').select();
    my_domains = []
    for my_site in sites:
        tmp = {}
        tmp['name'] = my_site['name']
        tmp_domains = public.M('domain').where('pid=?',
                                               (my_site['id'],)).field(
            'name').select()
        tmp['domains'] = []
        for domain in tmp_domains:
            tmp['domains'].append(domain['name'])
        binding_domains = public.M('binding').where('pid=?',
                                                    (my_site['id'],)).field(
            'domain').select()
        for domain in binding_domains:
            tmp['domains'].append(domain['domain'])
        my_domains.append(tmp)
    config_domains = LuaMaker.makeLuaTable(my_domains)
    domains_str = "return " + config_domains
    public.WriteFile("/www/server/total/domains.lua", domains_str)

def sync_config():
    print("正在同步配置...")
    config = json.loads(public.readFile("/www/server/total/config.json"))
    lua_config = LuaMaker.makeLuaTable(config)
    lua_config = "return " + lua_config
    public.WriteFile("/www/server/total/total_config.lua", lua_config)
    write_site_domains()
    print("配置同步完成。")

if __name__ == "__main__":
    check_database()
    alter_columns()
    sync_config()

        

