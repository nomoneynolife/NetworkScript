# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# | Maintainer: linxiao
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   宝塔网站监控报表
# +--------------------------------------------------------------------
from __future__ import absolute_import, print_function, division
import sys, os
import json,time,re,datetime

_ver = sys.version_info
is_py2 = (_ver[0] == 2)
is_py3 = (_ver[0] == 3)

os.chdir("/www/server/panel")
sys.path.insert(0, "class/")

import public
from panelAuth import panelAuth
from BTPanel import get_input, cache
from tsqlite import tsqlite
from total_migrate import total_migrate
from lua_maker import LuaMaker


class total_main:
    __plugin_path = '/www/server/total'
    __frontend_path = '/www/server/panel/plugin/total'
    __config = {}
    close_file = "/www/server/total/closing"

    def __init__(self):
        pass

    def log(self, msg):
        log_file = "/www/server/panel/logs/error.log"
        if is_py3:
            with open(log_file, "a", encoding="utf-8") as fp:
                fp.write(msg + "\n")
        else:
            with open(log_file, "a") as fp:
                fp.write(msg + "\n")

    def flush_data(self, site):
        try:
            import time
            import random
            flush_url = "http://127.0.0.1:80/bt_total_flush_data?time="+str(time.time()) + str(random.randint(0, 100)) + "\&server_name="+site
            print(flush_url)
            res = public.ExecShell("curl "+flush_url)
        except Exception as e:
            self.log("刷新数据异常："+str(e))
        
    def get_config(self, site=None):
        if self.__config and site in self.__config.keys(): return self.__config[site]
        data = public.readFile(self.__plugin_path + '/config.json')
        config = json.loads(data)
        if site in config.keys():
            global_config = config["global"]
            for k, v in config[site].items():
                if k not in global_config.keys():
                    config[site][k] = global_config[k]
            if not global_config["monitor"]:
                config[site]["monitor"] == False
            self.__config[site] = config[site]
        else:
            self.__config[site] = config["global"]
        return self.__config[site]
        

    def set_status(self, get):
        self.__read_config()
        self.__config['global']["monitor"] = not self.__config['global']['monitor']
        self.__write_config()
        self.__write_logs("设置网站监控插件状态为[%s]" % (self.__config['global']['monitor'],))
        return public.returnMsg(True, '设置成功!')

    def set_site_value(self, get):
        self.__read_config()
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site

        if type(self.__config[site][get.s_key]) == bool:
            get.s_value = not self.__config[site][get.s_key]
        elif type(self.__config[get.siteName][get.s_key]) == int:
            get.s_value = int(get.s_value)
        self.__config[get.siteName][get.s_key] = get.s_value
        self.__write_logs(
            "设置网站[%s]的[%s]配置项为[%s]" % (site, get.s_key, get.s_value))
        self.__write_config()
        return public.returnMsg(True, '设置成功!');

    def get_total_ip(self, get):
        self.__read_config()
        data = {}
        data['total_ip'] = self.__config['sites'][get.siteName]['total_ip']
        data['total_uri'] = self.__config['sites'][get.siteName]['total_uri']
        return data

    def add_total_ip(self, get):
        self.__read_config()
        if get.ip in self.__config['sites'][get.siteName][
            'total_ip']: return public.returnMsg(False, '指定URI已存在!');
        self.__config['sites'][get.siteName]['total_uri'][get.uri_name] = 0;
        self.__write_logs("向网站[%s]添加自定义统计IP[%s]" % (get.siteName, get.ip))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_total_ip(self, get):
        self.__read_config()
        del (self.__config['sites'][get.siteName]['total_ip'][get.ip])
        self.__write_logs("从网站[%s]删除自定义统计IP[%s]" % (get.siteName, get.ip))
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_total_uri(self, get):
        self.__read_config()
        return self.__config['sites'][get.siteName]['total_uri']

    def add_total_uri(self, get):
        self.__read_config()
        if get.uri_name in self.__config['sites'][get.siteName][
            'total_uri']: return public.returnMsg(False, '指定URI已存在!');
        self.__config['sites'][get.siteName]['total_uri'][get.uri_name] = 0;
        self.__write_logs(
            "向网站[%s]添加自定义统计URI[%s]" % (get.siteName, get.uri_name))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_total_uri(self, get):
        self.__read_config()
        del (self.__config['sites'][get.siteName]['total_uri'][get.uri_name])
        self.__write_logs(
            "从网站[%s]删除自定义统计URI[%s]" % (get.siteName, get.uri_name))
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        return self.__config[site]['exclude_status']

    def add_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        if get.status in self.__config[site]['exclude_status']: 
            return public.returnMsg(False, '指定响应状态已存在!');
        self.__config[site]['exclude_status'].insert(0, get.status)
        self.__write_logs("向网站[%s]添加响应状态排除[%s]" % (site, get.status))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        status = get.status
        self.__write_logs("从网站[%s]删除响应状态排除[%s]" % (site, status))
        self.__config[site]['exclude_status'].remove(status)
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_log_exclude_extension(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        return self.__config[site]['exclude_extension']

    def add_log_exclude_extension(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        if get.ext_name in self.__config[site]['exclude_extension']: return public.returnMsg(False,
                                                              '指定扩展名已存在!');
        self.__config[site]['exclude_extension'].insert(0, get.ext_name)
        self.__write_logs("向网站[%s]添加扩展名排除[%s]" % (site, get.ext_name))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_log_exclude_extension(self, get):
        self.__read_config()
        ext_name = get.ext_name
        self.__write_logs("从网站[%s]删除扩展名排除[%s]" % (site, ext_name))
        self.__config[get.siteName]['log_exclude_extension'].remove(
            ext_name)
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_global_total(self, get):
        self.__read_config()
        data = {}
        data['client'] = self.__get_file_json(
            self.__plugin_path + '/total/client.json')
        data['area'] = self.__get_file_json(
            self.__plugin_path + '/total/area.json')
        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/network.json')
        data['request'] = self.__get_file_json(
            self.__plugin_path + '/total/request.json')
        data['spider'] = self.__get_file_json(
            self.__plugin_path + '/total/spider.json')
        data['open'] = self.__config['open']
        return data

    def get_sites(self, get):
        # self._check_site()
        if os.path.exists('/www/server/apache'):
            if not os.path.exists('/usr/local/memcached/bin/memcached'):
                return public.returnMsg(False, '需要memcached,请先到【软件管理】页面安装!')
            if not os.path.exists('/var/run/memcached.pid'):
                return public.returnMsg(False, 'memcached未启动,请先启动!')
        # modc = self.__get_mod(get)
        # if not cache.get('bt_total'):  return modc
        result = {}
        data = []
        
        res = self.get_site_lists(get)
        if not res["status"]:
            return data
        site_lists = res["data"]
        for siteName in site_lists:
            tmp = {}
            tmp['total'] = self.__get_site_total(siteName)
            tmp['site_name'] = siteName
            data.append(tmp)
        data = sorted(data, key=lambda x: x['total']['request'], reverse=True)
        data = sorted(data, key=lambda x: x['total']['day_request'],
                      reverse=True)
        result['data'] = data
        result['open'] = self.get_config()['monitor']
        self.write_site_domains()
        return result

    def __get_mod(self, get):
        # filename = '/www/server/panel/plugin/bt_total/bt_total_init.py';
        # if os.path.exists(filename): os.remove(filename);
        if cache.get('bt_total'): return public.returnMsg(True, 'OK!');
        cache.set('bt_total', True)
        return public.returnMsg(True,'OK!');
        tu = '/proc/sys/net/ipv4/tcp_tw_reuse'
        if public.readFile(tu) != '1': public.writeFile(tu, '1');
        params = {}
        params['pid'] = '100000014';
        result = panelAuth().send_cloud('check_plugin_status', params)
        try:
            if not result['status']:
                if cache.get('bt_total'): cache.delete('bt_total')
                return result;
        except:
            pass;
        cache.set('bt_total', True)
        return result

    def get_log_db_path(self, site):
        db_path = os.path.join(self.__plugin_path,
                               "logs/{}/logs.db".format(site))
        return db_path

    def get_time_key(self, date=None):
        if date is None:
            date = time.localtime()
        time_key = 0
        time_key_format = "%Y%m%d%H"
        if type(date) == time.struct_time:
            time_key = int(time.strftime(time_key_format, date))
        if type(date) == str:
            time_key = int(time.strptime(date, time_key_format))
        return time_key

    def get_time_interval(self, local_time):
        start = None
        end = None
        time_key_format = "%Y%m%d00"
        start = int(time.strftime(time_key_format, local_time))
        time_key_format = "%Y%m%d23"
        end = int(time.strftime(time_key_format, local_time))
        return start, end

    def get_timestamp_interval(self, local_time):
        start = None
        end = None
        start = time.mktime((local_time.tm_year, local_time.tm_mon,
                             local_time.tm_mday, 0, 0, 0, 0, 0, 0))
        end = time.mktime((local_time.tm_year, local_time.tm_mon,
                           local_time.tm_mday, 23, 59, 59, 0, 0, 0))
        return start, end

    def get_last_days_by_timestamp(self, day):
        now = time.localtime()
        t1 = time.mktime(
            (now.tm_year, now.tm_mon, now.tm_mday - day + 1, 0, 0, 0, 0, 0, 0))
        t2 = time.localtime(t1)
        start, _ = self.get_timestamp_interval(t2)
        _, end = self.get_timestamp_interval(now)
        return start, end

    def get_last_days(self, day):
        now = time.localtime()
        t1 = time.mktime(
            (now.tm_year, now.tm_mon, now.tm_mday - day + 1, 0, 0, 0, 0, 0, 0))
        t2 = time.localtime(t1)
        start, _ = self.get_time_interval(t2)
        _, end = self.get_time_interval(now)
        return start, end

    def get_query_timestamp(self, query_date):
        """获取查询日期的时间戳 """
        try:
            start_date = None
            end_date = None
            if query_date == "today":
                start_date, end_date = self.get_timestamp_interval(
                    time.localtime())
            elif query_date == "yesterday":
                # day - 1
                now = time.localtime()
                yes_i = time.mktime((
                                    now.tm_year, now.tm_mon, now.tm_mday - 1, 0,
                                    0, 0, 0, 0, 0))
                yes = time.localtime(yes_i)
                start_date, end_date = self.get_timestamp_interval(yes)
            elif query_date.startswith("l"):
                days = int(query_date[1:])
                start_date, end_date = self.get_last_days_by_timestamp(days)
            else:
                if query_date.find("-") < 0:
                    if query_date.isdigit():
                        s_time = time.strptime(query_date, "%Y%m%d")
                        start_date, end_date = self.get_timestamp_interval(
                            s_time)
                else:
                    s, e = query_date.split("-")
                    start_time = time.strptime(s.strip(), "%Y%m%d")
                    start_date, _ = self.get_timestamp_interval(start_time)
                    end_time = time.strptime(e.strip(), "%Y%m%d")
                    _, end_date = self.get_timestamp_interval(end_time)

        except Exception as e:
            print("query timestamp exception:", str(e))
        return start_date, end_date

    def get_query_date(self, query_date):
        """获取查询日期
        
        查询日期的表示形式是以区间的格式表示，这里也考虑到了数据库里面实际存储的方式。
        在数据库里面是以小时为单位统计日志数据，所以这里的区间也是也小时来表示。
        比如表示今天，假设今天是2021/3/30，查询日期的格式是2021033000-2021033023。
        """
        try:
            start_date = None
            end_date = None
            if query_date == "today":
                start_date, end_date = self.get_time_interval(time.localtime())
            elif query_date == "yesterday":
                # day - 1
                now = time.localtime()
                yes_i = time.mktime((
                                    now.tm_year, now.tm_mon, now.tm_mday - 1, 0,
                                    0, 0, 0, 0, 0))
                yes = time.localtime(yes_i)
                start_date, end_date = self.get_time_interval(yes)
            elif query_date.startswith("l"):
                days = int(query_date[1:])
                start_date, end_date = self.get_last_days(days)
            else:
                if query_date.find("-") < 0:
                    if query_date.isdigit():
                        s_time = time.strptime(query_date, "%Y%m%d")
                        start_date, end_date = self.get_time_interval(s_time)
                else:
                    s, e = query_date.split("-")
                    start_time = time.strptime(s.strip(), "%Y%m%d")
                    start_date, _ = self.get_time_interval(start_time)
                    end_time = time.strptime(e.strip(), "%Y%m%d")
                    _, end_date = self.get_time_interval(end_time)

        except Exception as e:
            print("query date exception:", str(e))
        return start_date, end_date

    def get_compare_date(self, query_start_date, compare_date):
        """获取对比日期"""
        try:
            start_date = time.strptime(str(query_start_date), "%Y%m%d%H")
            end_date = None
            if compare_date == "yesterday":
                yes_i = time.mktime((start_date.tm_year, start_date.tm_mon,
                                     start_date.tm_mday - 1, 0, 0, 0, 0, 0, 0))
                yes = time.localtime(yes_i)
                start_date, end_date = self.get_time_interval(yes)
            elif compare_date == "lw":
                week_i = time.mktime((start_date.tm_year, start_date.tm_mon,
                                      start_date.tm_mday - 7, 0, 0, 0, 0, 0, 0))
                week = time.localtime(week_i)
                start_date, end_date = self.get_time_interval(week)
            else:
                if compare_date.find("-") < 0:
                    if compare_date.isdigit():
                        s_time = time.strptime(compare_date, "%Y%m%d")
                        start_date, end_date = self.get_time_interval(s_time)
                else:
                    # print("区间时间：", compare_date)
                    s, e = compare_date.split("-")
                    start_time = time.strptime(s.strip(), "%Y%m%d")
                    start_date, _ = self.get_time_interval(start_time)
                    end_time = time.strptime(e.strip(), "%Y%m%d")
                    _, end_date = self.get_time_interval(end_time)

            return start_date, end_date
        except Exception as e:
            print("compare date exception:", str(e))
        return None, None

    def get_realtime_request(self, site=None):
        """获取实时请求数"""
        res_data = []
        if site is not None:
            log_file = self.__plugin_path + "/logs/{}/req_sec.json".format(site)
            if not os.path.isfile(log_file):
                return res_data

            datetime_now = datetime.datetime.now()
            req_data = public.readFile(log_file)
            lines = req_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _rt_req, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    # print(datetime_log.strftime("%y%m%d %H:%M:%S"))
                    datetime_interval = datetime_now - datetime_log
                    # print("interval:", datetime_interval.seconds)
                    if datetime_interval.seconds < 3:
                        data = {"timestamp": _write_time, "req": int(_rt_req)}
                        res_data.append(data)

                except Exception as e:
                    print("实时数据转换异常:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data

    def get_realtime_traffic(self, site=None):
        """获取实时流量"""
        res_data = []
        if site is not None:
            flow_file = self.__plugin_path + "/logs/{}/flow_sec.json".format(
                site)
            if not os.path.isfile(flow_file):
                return res_data
            flow_data = public.readFile(flow_file)
            datetime_now = datetime.datetime.now()
            # print("Now:", datetime_now.strftime("%Y%m%d %H:%M:%S"))
            # print("Now:", datetime_now.timestamp())
            lines = flow_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _flow, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    datetime_interval = datetime_now - datetime_log
                    if datetime_interval.seconds < 3:
                        # print("flow interval by datetime:", datetime_interval.seconds)
                        # print(datetime_log.strftime("%Y%m%d %H:%M:%S"), _flow)
                        data = {"timestamp": _write_time, "flow": int(_flow)}
                        res_data.append(data)

                except Exception as e:
                    print("实时流量获取出现错误:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data

    def get_refresh_interval(self, site):
        global_config = self.get_site_settings("global")
        return global_config["refresh_interval"]

    def get_refresh_status(self, site):
        global_config = self.get_site_settings("global")
        return global_config["autorefresh"]

    def get_monitor_status(self, site):
        global_config = self.get_site_settings("global")
        if not global_config["monitor"]:
            return False
        config = self.get_site_settings(site)
        return config["monitor"]

    def init_site_db(self, site):
        """初始化数据库"""
        tm = total_migrate()
        tm.init_site_db(site)

    def init_ts(self, site):
        self.init_site_db(site)
        db_path = self.get_log_db_path(site)
        ts = tsqlite()
        ts.dbfile(db_path)
        return ts

    def get_site_overview_sum_data(self, site, start_date, end_date):
        """获取站点概览页的统计数据"""
        ts = self.init_ts(site)
        sum_data = {}
        if not ts:
            default_fields = "req,pv,uv,ip,length,spider,s50x,s40x"
            for field in default_fields.split(","):
                sum_data[field] = 0
            return sum_data
        # 统计数据
        s50x_fields = ",sum(status_500+status_501+status_502+status_503+status_504+status_505+status_506+status_507+status_509+status_510) as s50x"
        s40x_fields = ",sum(status_400+status_401+status_402+status_403+status_404+status_405+status_406+status_407+status_408+status_409+status_410+status_411+status_412+status_413+status_414+status_415+status_416+status_417+status_418+status_421+status_422+status_423+status_424+status_425+status_426+status_449+status_451) as s40x"
        total_fields = "sum(req) as req, sum(pv) as pv, sum(uv) as uv, sum(ip) as ip, sum(length) as length, sum(spider) as spider"
        total_fields += s50x_fields + s40x_fields
        ts.table("request_stat").field(total_fields)
        ts.where("time between ? and ?", (start_date, end_date))
        sum_data = ts.find()
        print("sum data:")
        print(sum_data)

        for key, value in sum_data.items():
            if not value:
                sum_data[key] = 0

        if type(sum_data) != dict:
            sum_data = {}
        return sum_data

    def get_overview_by_day(self, site, start_date, end_date, time_scale="hour",
                            target=None):
        """获取某一段时间的概览数据"""
        data = []
        sum_data = {}

        ts = self.init_ts(site)
        if not ts:
            return data, self.get_site_overview_sum_data(site, start_date,
                                                         end_date)

        if target is None:
            target = "pv"

        allow_target = ["pv", "uv", "ip", "req", "length", "spider", "s50x", "s40x"]
        if target in allow_target:
            # 绘图数据
            if time_scale == "hour":
                ts.table("request_stat").field("time," + target)
                ts.where("time between ? and ?", (start_date, end_date))
                ts.order("time")
            elif time_scale == "day":
                sum_fields = "sum(" + target + ") as " + target
                sum_fields = "time/100 as time1," + sum_fields
                ts.table("request_stat").groupby("time1").field(sum_fields)
                ts.where("time between ? and ?", (start_date, end_date))
                ts.order("time1")

            data = ts.select()
            if type(data) != list:
                data = []
            if time_scale == "day":
                for d in data:
                    d["time"] = d["time1"]
                    del d["time1"]

        sum_data = self.get_site_overview_sum_data(site, start_date, end_date)
        return data, sum_data

    def get_site_overview(self, get):
        try:
            ts = None
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            target = "pv"
            if 'target' in get:
                target = get.target
            time_scale = 'hour'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time

            # if request_time is not None:
            #     print("请求时间{}以后的数据。".format(request_time))

            self.flush_data(site)
            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}

            start_date, end_date = self.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))
            if request_time is not None:
                data, sum_data = self.get_overview_by_day(
                    site, request_time, end_date,
                    time_scale=time_scale, target=target)
            else:
                data, sum_data = self.get_overview_by_day(
                    site, start_date, end_date,
                    time_scale=time_scale, target=target)

            if compare:
                compare_start_date, compare_end_date = self.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_overview_by_day(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=target)

            realtime_req = self.get_realtime_request(site=site)
            realtime_traffic = self.get_realtime_traffic(site=site)

            request_time = self.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if compare:
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            migrate = self.get_migrate_status({})
            migrate_status = False
            if migrate["status"] == "completed":
                migrate_status = True

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "target": target,
                "time_scale": time_scale,
                "data": data,
                "sum_data": sum_data,
                "realtime_request": realtime_req,
                "realtime_traffic": realtime_traffic,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "migrated": migrate_status,
                "autorefesh": self.get_refresh_status(site),
                "refresh_interval": self.get_refresh_interval(site),
                "monitor": self.get_monitor_status(site)
            }
            self.switch_site(get)
            return res_data
        except RuntimeError as e:
            print(e)
        # finally:
        #     if ts:
        #         ts.close()

        return public.returnMsg(False, "获取数据异常。")

    def get_top_spiders(self, site, start_date, end_date, target, top):
        ts = self.init_ts(site)
        sum_fields = ""
        top = 10
        spiders = []
        if not ts:
            return []

        if not target or target == "top":
            spider_config = self.__plugin_path + "/config/spiders.json"
            spiders = self.__get_file_json(spider_config)
            # 动态生成数据列
            for spider in spiders:
                spider_name = spider["column"]

                if sum_fields:
                    sum_fields += ","
                sum_fields += "sum(" + spider_name + ") as " + spider_name

            ts.table("spider_stat").field(sum_fields)
            ts.where("time between ? and ?", (start_date, end_date))
            sum_data = ts.find()
            # print("sum data:", sum_data)
            top_columns = []
            # print(sorted(sum_data, key=lambda kv:(kv[1], kv[0]), reverse=True))
            if len(sum_data) and type(sum_data) != str:
                _columns = sorted(sum_data.items(),
                                  key=lambda kv: (kv[1], kv[0]),
                                  reverse=True)
                for i in range(len(_columns)):
                    if i == top: break
                    top_columns.append(_columns[i][0])
        else:
            if target.find(",") >= 0:
                top_columns = target.split(",")
            else:
                top_columns = [target]
        return top_columns

    def get_site_spider_stat_by_time_interval(self, site, start_date, end_date,
                                              time_scale="hour", target=None):
        """获取某一时间区间的蜘蛛统计数据
        :site 站点名
        :start_date 起始时间
        :end_date 终止时间
        :time_scale 时间刻度
        :target 绘图指标
        """
        data = []
        sum_data = {}

        db_path = self.get_log_db_path(site)
        if not os.path.isfile(db_path):
            return data, sum_data

        ts = tsqlite()
        ts.dbfile(db_path)
        new_target = ""
        top_columns = target
        top = len(top_columns)

        # 2. 根据统计数据查询图表数据
        if time_scale == "hour":
            fields = ",".join(top_columns)
            fields = "time," + fields
            ts.table("spider_stat").field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            data = ts.select()
        elif time_scale == "day":
            fields = ""
            for i, col in enumerate(top_columns):
                if i == top: break
                if fields:
                    fields += ","
                fields += "sum(" + col + ") as " + col
            # print("fields :", fields)
            # print("start:{}/end:{}".format(start_date, end_date))
            ts.table("spider_stat").field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            _data = ts.find()
            for column in top_columns:
                data.append({column: _data[column]})

        spider_config = self.__plugin_path + "/config/spiders.json"
        spiders = self.__get_file_json(spider_config)

        total_data = {}

        total_field = ""
        for spider in spiders:
            if total_field:
                total_field += "+"
            total_field += spider["column"]
        total_field = "sum(" + total_field + ") as total"
        ts.table("spider_stat").field(total_field)
        ts.where("time between ? and ?", (start_date, end_date))
        total_res = ts.find()
        total_data["spider_total"] = total_res["total"]

        # 补充总请求数
        ts.table("request_stat").field("sum(req) as req")
        ts.where("time between ? and ?", (start_date, end_date))
        total_req = ts.find()
        if total_req:
            total_data["total_req"] = total_req["req"]
        else:
            total_data["total_req"] = 0

        return data, total_data

    def get_spider_list(self, site, start_date, end_date, order="time",
                        desc=True, page_size=20, page=1):
        """获取蜘蛛统计列表数据"""

        list_data = []
        total_row = 0
        ts = self.init_ts(site)
        if not ts:
            return list_data, total_row

        spider_config = self.__plugin_path + "/config/spiders.json"
        spiders = self.__get_file_json(spider_config)
        sum_fields = ""
        # 动态生成数据列
        for spider in spiders:
            spider_name = spider["column"]
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + spider_name + ") as " + spider_name

        # 列表数据查询
        list_fields = "time/100 as time1, " + sum_fields
        ts.table("spider_stat").field(list_fields).groupby("time1")
        # ts.where("time between ? and ?", (start_date, end_date))
        if "time" == order:
            order = "time1"
        if desc:
            order += " desc"
        page_start = (page - 1) * page_size
        ts.order(order)
        list_data = ts.select()
        total_row = len(list_data)
        list_data = list_data[page_start:page_start + page_size]
        for d in list_data:
            d["time"] = d["time1"]
            del d["time1"]
        return list_data, total_row

    def get_spider_stat(self, get):
        try:
            ts = None
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            time_scale = 'hour'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            target = "top"
            if "target" in get:
                target = get.target
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            # if request_time is not None:
            #     print("请求时间{}以后的数据。".format(request_time))

            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}
            list_data = []
            total_row = 0

            start_date, end_date = self.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))

            ts = tsqlite()
            db_path = self.get_log_db_path(site)

            request_time = self.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if not os.path.isfile(db_path):
                # print("监控数据为空。")
                return {
                    "status": True,
                    "query_date": res_query_date,
                    "data": data,
                    "sum_data": sum_data,
                    "compare": compare,
                    "compare_date": res_compare_date,
                    "compare_data": compare_data,
                    "compare_sum_data": compare_sum_data,
                    "request_data_time": request_time,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "autorefesh": self.get_refresh_status(site),
                    "monitor": self.get_monitor_status(site)
                }

            self.flush_data(site)
            top = 5
            # self.log("site:" + site)
            top_columns = self.get_top_spiders(site, start_date, end_date,
                                               target, top)
            if request_time is not None:
                # 默认top的情况下，每次重新请求
                if target and target != "top":
                    data, sum_data = self.get_site_spider_stat_by_time_interval(
                        site, request_time, end_date, time_scale=time_scale,
                        target=top_columns)
                else:
                    data, sum_data = self.get_site_spider_stat_by_time_interval(
                        site, start_date, end_date, time_scale=time_scale,
                        target=top_columns)
                list_data, total_row = self.get_spider_list(site, request_time,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)
            else:
                data, sum_data = self.get_site_spider_stat_by_time_interval(
                    site, start_date, end_date, time_scale=time_scale,
                    target=top_columns)
                list_data, total_row = self.get_spider_list(site, start_date,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)

            if compare:
                compare_start_date, compare_end_date = self.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_site_spider_stat_by_time_interval(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=top_columns)
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "data": data,
                "sum_data": sum_data,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "autorefesh": self.get_refresh_status(site),
                "monitor": self.get_monitor_status(site)
            }
            self.switch_site(get)
            return res_data
        except RuntimeError as e:
            print(e)

        return public.returnMsg(False, "获取数据异常。")

    def get_site_client_stat_by_time_interval(self, site, start_date, end_date,
                                              time_scale="hour", target=None):
        """获取某一时间区间的客户端统计数据
        :site 站点名
        :start_date 起始时间
        :end_date 终止时间
        :time_scale 时间刻度
        :target 绘图指标
        """
        data = []
        sum_data = {}

        db_path = self.get_log_db_path(site)
        if not os.path.isfile(db_path):
            return data, sum_data

        ts = tsqlite()
        ts.dbfile(db_path)
        new_target = ""
        top_columns = target
        top = len(top_columns)
        table_name = "client_stat"

        # 2. 根据统计数据查询图表数据
        if time_scale == "hour":
            fields = ",".join(top_columns)
            fields = "time," + fields
            ts.table(table_name).field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            data = ts.select()
        elif time_scale == "day":
            fields = ""
            for i, col in enumerate(top_columns):
                if i == top: break
                if fields:
                    fields += ","
                fields += "sum(" + col + ") as " + col
            ts.table(table_name).field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            _data = ts.find()
            for column in top_columns:
                data.append({column: _data[column]})

        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        total_data = {}

        clients_json = self.__plugin_path + "/config/clients.json"
        config_clients = self.__get_file_json(clients_json)
        pc_clients = config_clients["pc"]
        mobile_clients = config_clients["mobile"]

        total_field = ""
        pc_field = ""
        mobile_field = ""
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            for pc in pc_clients:
                if client_name == pc["column"]:
                    if pc_field:
                        pc_field += "+"
                    pc_field += client_name
                    break

            for mobile in mobile_clients:
                if client_name == mobile["column"]:
                    if mobile_field:
                        mobile_field += "+"
                    mobile_field += client_name

        pc_field = "sum(" + pc_field + ") as pc"
        mobile_field = "sum(" + mobile_field + ") as mobile"
        ts.table(table_name).field(",".join([pc_field, mobile_field]))
        ts.where("time between ? and ?", (start_date, end_date))
        total_res = ts.find()
        total_data["total_pc"] = total_res["pc"]
        total_data["total_mobile"] = total_res["mobile"]

        # 补充总请求数
        ts.table("request_stat").field("sum(req) as req")
        ts.where("time between ? and ?", (start_date, end_date))
        total_req = ts.find()
        if total_req:
            total_data["total_req"] = total_req["req"]
        else:
            total_data["total_req"] = 0

        return data, total_data

    def get_client_list(self, ts, site, start_date, end_date, order="time",
                        desc=False, page_size=20, page=1):
        """获取客户端统计列表数据"""

        if not ts:
            ts = tsqlite()
            db_path = self.get_log_db_path(site)
            ts.dbfile(db_path)

        table_name = "client_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        sum_fields = ""
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + client_name + ") as " + client_name

        # 列表数据查询
        list_fields = "time/100 as time1, " + sum_fields
        ts.table(table_name).field(list_fields).groupby("time1")
        # ts.where("time between ? and ?", (start_date, end_date))
        if order == "time":
            order = "time1"
        if desc:
            order += " desc"
        ts.order(order)
        _data = ts.select()
        other_clients = ["metasr", "theworld", "tt", "maxthon", "opera", "qq",
                         "uc", "pc2345", "other"]
        list_data = []
        total_row = len(_data)
        page_start = (page - 1) * page_size
        _data = _data[page_start:page_start + page_size]
        for client_data in _data:
            tmp = {}
            other = {}
            for key, value in client_data.items():
                if key in other_clients:
                    other[key] = value
                else:
                    if key == "time1":
                        tmp["time"] = value
                    else:
                        tmp[key] = value
            tmp.update({"other": other})
            list_data.append(tmp)
        return list_data, total_row

    def get_top_clients(self, db, start_date, end_date, top=3):
        ts = db
        sum_fields = ""
        clients = []
        table_name = "client_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        # print("columns:", str(columns))
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + client_name + ") as " + client_name

        ts.table(table_name).field(sum_fields)
        ts.where("time between ? and ?", (start_date, end_date))
        sum_data = ts.find()
        top_columns = []
        # print(sorted(sum_data, key=lambda kv:(kv[1], kv[0]), reverse=True))
        if len(sum_data):
            _columns = sorted(sum_data.items(), key=lambda kv: (kv[1], kv[0]),
                              reverse=True)
            for i in range(len(_columns)):
                if i == top: break
                top_columns.append(_columns[i][0])
        return top_columns

    def get_client_stat(self, get):
        try:
            ts = None
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            time_scale = 'day'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            target = "top"
            if "target" in get:
                target = get.target
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False

            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}
            list_data = []
            total_row = 0

            start_date, end_date = self.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))

            res_query_date = "{}-{}".format(start_date, end_date)
            db_path = self.get_log_db_path(site)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "data": data,
                    "sum_data": sum_data,
                    "compare": compare,
                    "compare_date": res_query_date,
                    "compare_data": compare_data,
                    "compare_sum_data": compare_sum_data,
                    "request_data_time": request_time,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "autorefesh": self.get_refresh_status(site),
                    "monitor": self.get_monitor_status(site)
                }
                return res_data

            self.flush_data(site)
            ts = tsqlite()
            ts.dbfile(db_path)

            top_columns = []
            top = 10
            if target == "top":
                top_columns = self.get_top_clients(ts, start_date, end_date,
                                                   top)
            else:
                if target.find(",") >= 0:
                    top_columns = target.split(",")
                else:
                    top_columns = [target]

            if request_time is not None:
                # 默认top的情况下，每次重新请求
                if target and target != "top":
                    data, sum_data = self.get_site_client_stat_by_time_interval(
                        site, request_time, end_date, time_scale=time_scale,
                        target=top_columns)
                else:
                    data, sum_data = self.get_site_client_stat_by_time_interval(
                        site, start_date, end_date, time_scale=time_scale,
                        target=top_columns)
                list_data, total_row = self.get_client_list(ts, site,
                                                            request_time,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)
            else:
                data, sum_data = self.get_site_client_stat_by_time_interval(
                    site, start_date, end_date, time_scale=time_scale,
                    target=top_columns)
                list_data, total_row = self.get_client_list(ts, site,
                                                            start_date,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)

            if compare:
                compare_start_date, compare_end_date = self.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_site_client_stat_by_time_interval(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=top_columns)

            request_time = self.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if compare:
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "data": data,
                "sum_data": sum_data,
                "target": target,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "autorefesh": self.get_refresh_status(site),
                "monitor": self.get_monitor_status(site)
            }
            return res_data
        except RuntimeError as e:
            print(e)
        # finally:
        # if ts:
        #     ts.close()

        return public.returnMsg(False, "获取数据异常。")

    def get_error_code(self, get):
        error_code = [
            "all", "50x", "40x", "500", "501", "502", "503", "404"
        ]
        return {"status_codes": error_code}

    def get_site_error_sql(self, start_date, end_date, status_code, *args, **kwargs):
        if True:
            status_code_50x = [500, 501, 502, 503, 504, 505, 506, 507, 509, 510]
            status_code_40x = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409,
                               410, 411, 412, 413, 414, 415, 416, 417, 418, 421, 
                               422, 423, 424, 425, 426, 449, 451]
            if status_code == "50x":
                status_codes = ",".join([str(s) for s in status_code_50x])
            elif status_code == "40x":
                status_codes = ",".join([str(s) for s in status_code_40x])
            elif status_code == "all":
                status_codes = ",".join(
                    [str(s) for s in (status_code_50x + status_code_40x)])
            else:
                status_codes = status_code
            # ts.table("site_logs").field(fields)
            where_sql = " where time between {} and {}".format(start_date, end_date)
            where_sql += " and status_code in ({})".format(status_codes)
            conditions = kwargs
            if "spider" in conditions.keys():
                spider = conditions["spider"].lower()
                if spider == "only_spider":
                    where_sql += " and is_spider=1"
                if spider == "no_spider":
                    where_sql += " and is_spider=0"

            select_sql = "select {} from site_logs" + where_sql
            # print(select_sql)
            return select_sql

    def get_site_error_logs_total(self, get):
        try:
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            ts = tsqlite()
            db_path = self.get_log_db_path(site)
            ts.dbfile(db_path)

            start_date, end_date = self.get_query_timestamp(query_date)
            select_sql = self.get_site_error_sql(start_date, end_date, status_code, **conditions)
            total_sql = select_sql.format("count(*)")
            total_res = ts.query(total_sql)
            total_row = int(total_res[0][0])
            ts.close()
            return {"total_row":total_row}
        except:
            return 0

    def get_site_error_logs(self, get):
        try:
            ts = None
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            no_total = False
            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False

            list_data = []
            total_row = 0

            start_date, end_date = self.get_query_timestamp(query_date)
            res_query_date = "{}-{}".format(start_date, end_date)
            db_path = self.get_log_db_path(site)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                }
                return res_data

            self.flush_data(site)

            ts = tsqlite()
            ts.dbfile(db_path)

            select_sql = self.get_site_error_sql(start_date, end_date, status_code, **conditions)

            total_row = 0
            if not no_total:
                total_sql = select_sql.format("count(*)")
                total_res = ts.query(total_sql)
                total_row = int(total_res[0][0])

            fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers"
            select_data_sql = select_sql.format(fields)

            if orderby:
                select_data_sql += " order by " + orderby
            if desc:
                select_data_sql += " desc"
            
            page_start = (page - 1) * page_size
            # select_data_sql += " limit {},{}".format(str(page_start), str(page_size))
            select_data_sql += " limit {}".format(str(page_size))
            select_data_sql += " offset " + str(page_start)
            # print("select sql:")
            # print(select_data_sql)

            data = ts.query(select_data_sql)

            # select_end = datetime.datetime.now()
            # diff = select_end-select_start
            # diff_gmtime = time.gmtime(diff.total_seconds())
            # strtime = time.strftime("%H:%M:%S", diff_gmtime)
            # str_msec = '.' + str(diff)[-6:]
            # msec = '%.3f' % float(str_msec)
            # msec = msec[1:]
            # print("查询耗时:{}s".format(strtime+str(msec)))
            
            _columns = [column.strip() for column in fields.split(",")]
            for row in data:
                i = 0
                tmp1 = {}
                for column in _columns:
                    tmp1[column] = row[i]
                    i += 1
                list_data.append(tmp1)
                del (tmp1)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data
            }
            res_data.update(self.get_error_code(None))
            self.switch_site(get)
            return res_data
        except RuntimeError as e:
            print(e)
        # finally:
        # if ts:
        #     ts.close()

        return public.returnMsg(False, "获取数据异常。")
    
    def get_site_logs_sql(self, conditions):
        start_date = conditions["start_date"]
        end_date = conditions["end_date"]
        where_sql = " where time between {} and {}".format(start_date, end_date)
        if "status_code" in conditions.keys():
            status_code = conditions["status_code"]
            if status_code != "all":
                where_sql += " and status_code={}".format(status_code)
        if "method" in conditions.keys():
            method = conditions["method"]
            if method != "all":
                where_sql += " and method='{}'".format(method)
        if "search_url" in conditions.keys():
            search_url = conditions["search_url"]
            if search_url:
                where_sql += " and uri like '%{}%'".format(search_url)
        if "spider" in conditions.keys():
            spider = conditions["spider"].lower()
            if spider == "only_spider":
                where_sql += " and is_spider=1"
            if spider == "no_spider":
                where_sql += " and is_spider=0"
            
        select_sql = "select {} from site_logs" + where_sql
        return select_sql

    def get_site_logs_total(self, get):
        try:
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
                conditions["status_code"] = status_code
            if "method" in get:
                method = get.method
                conditions["method"] = method
            if "search_url" in get:
                url = get.search_url.strip()
                conditions["search_url"] = url
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            ts = tsqlite()
            db_path = self.get_log_db_path(site)
            ts.dbfile(db_path)

            start_date, end_date = self.get_query_timestamp(query_date)
            conditions.update({
                "start_date": start_date,
                "end_date": end_date
            })
            select_sql = self.get_site_logs_sql(conditions)
            total_sql = select_sql.format("count(*)")
            total_res = ts.query(total_sql)
            total_row = int(total_res[0][0])
            ts.close()
            return {"total_row":total_row}
        except:
            return 0

    def get_site_logs(self, get):
        try:
            ts = None
            conditions = {}
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            method = "all"
            if "method" in get:
                method = get.method
                conditions["method"] = method
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
                conditions["status_code"] = status_code
            url = ""
            if "search_url" in get:
                url = get.search_url.strip()
                conditions["search_url"] = url
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            no_total = False
            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False

            list_data = []
            total_row = 0

            start_date, end_date = self.get_query_timestamp(query_date)
            # self.log("查询日志时间周期2: {} - {}".format(start_date, end_date))

            res_query_date = "{}-{}".format(start_date, end_date)
            db_path = self.get_log_db_path(site)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                }
                return res_data

            self.flush_data(site)
            ts = tsqlite()
            ts.dbfile(db_path)

            conditions.update({
                "start_date": start_date,
                "end_date": end_date,
            })
            select_sql = self.get_site_logs_sql(conditions)
            # ts.table("site_logs").field(fields)
            total_row = 0
            if not no_total:
                total_fields = "count(*)"
                total_sql = select_sql.format(total_fields)
                total_res = ts.query(total_sql)
                total_row = int(total_res[0][0])

            # select_start = datetime.datetime.now()

            fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers"
            select_data_sql = select_sql.format(fields)
            if orderby:
                select_data_sql += " order by " + orderby
            if desc:
                select_data_sql += " desc"

            select_data_sql += " limit " + str(page_size)
            page_start = (page - 1) * page_size
            select_data_sql += " offset " + str(page_start)

            select_data_sql += ";"
            # print("select sql:")
            # print(select_data_sql)
            data = ts.query(select_data_sql)

            # select_end = datetime.datetime.now()
            # diff = select_end-select_start
            # diff_gmtime = time.gmtime(diff.total_seconds())
            # strtime = time.strftime("%H:%M:%S", diff_gmtime)
            # str_msec = '.' + str(diff)[-6:]
            # msec = '%.3f' % float(str_msec)
            # msec = msec[1:]
            # print("查询耗时:{}s".format(strtime+str(msec)))
            _columns = [column.strip() for column in fields.split(",")]
            for row in data:
                i = 0
                tmp1 = {}
                for column in _columns:
                    tmp1[column] = row[i]
                    i += 1
                list_data.append(tmp1)
                del (tmp1)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
            }
            self.switch_site(get)
            return res_data
        except RuntimeError as e:
            print(e)
        # finally:
        # if ts:
        #     ts.close()

        return public.returnMsg(False, "获取数据异常。")

    def get_all_site(self, get):
        """所有站点信息概览"""

        try:
            ts = None
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date

            orderby = "pv"
            if "orderby" in get:
                orderby = get.orderby

            desc = True
            if "desc" in get:
                desc = True if get.desc == "true" else False

            sum_data = {}
            res_data = []
            list_data = []

            start_date, end_date = self.get_query_date(query_date)
            sites = public.M('sites').field('name').order("addtime").select();

            total_pv = 0
            total_uv = 0
            total_ip = 0
            total_req = 0
            total_length = 0
            total_spider = 0
            total_error = 0
            total_50x = 0
            total_40x = 0
            total_realtime_req = 0
            total_realtime_traffic = 0
            for site_info in sites:
                site = site_info["name"]
                site_overview_info = self.get_site_overview_sum_data(
                    site, start_date, end_date)
                data = {
                    "name": site, "pv": 0, "uv": 0, "ip": 0, "req": 0,
                    "length": 0, "spider": 0, "s50x": 0, "s40x":0
                }
                data.update(site_overview_info)
                realtime_req_list = self.get_realtime_request(site)
                if len(realtime_req_list) > 0:
                    data["realtime_req"] = realtime_req_list[0]["req"]
                else:
                    data["realtime_req"] = 0

                realtime_traffic_list = self.get_realtime_traffic(site)
                if len(realtime_traffic_list) > 0:
                    data["realtime_traffic"] = realtime_traffic_list[0]["flow"]
                else:
                    data["realtime_traffic"] = 0

                total_pv += data["pv"]
                total_uv += data["uv"]
                total_ip += data["ip"]
                total_req += data["req"]
                total_length += data["length"]
                total_spider += data["spider"]
                total_50x += data["s50x"]
                total_40x += data["s40x"]

                total_realtime_req += data["realtime_req"]
                total_realtime_traffic += data["realtime_traffic"]

                data["status"] = self.get_monitor_status(site)
                list_data.append(data)

            def sort_key(d):
                return d[orderby]

            list_data.sort(key=sort_key, reverse=desc)

            res_data = {
                "sum_data": {
                    "pv": total_pv,
                    "uv": total_uv,
                    "ip": total_ip,
                    "req": total_req,
                    "length": total_length,
                    "spider": total_spider,
                    "s50x": total_50x,
                    "s40x": total_40x,
                    "realtime_req": total_realtime_req,
                    "realtime_traffic": total_realtime_traffic
                },
                "list_data": list_data,
                "orderby": orderby,
                "desc": desc
            }
            return res_data
        except RuntimeError as e:
            print(e)

    def __read_frontend_config(self):
        config_json = self.__frontend_path + "/config.json"
        data = {}
        if os.path.exists(config_json):
            data = json.loads(public.readFile(config_json))
        return data

    def set_default_site(self, site):
        config = self.__read_frontend_config()
        config["default_site"] = site
        config_json = self.__frontend_path + "/config.json"
        public.writeFile(config_json, json.dumps(config))
        return True

    def switch_site(self, post):
        site = post.site
        if self.set_default_site(site):
            return public.returnMsg(True, "已切换默认站点为{}".format(site))
        return public.returnMsg(False, "切换默认站点失败。")

    def get_default_site(self):
        config = self.__read_frontend_config()
        default = None
        if "default_site" in config:
            default = config["default_site"]
        if not default:
            site = public.M('sites').field('name').order("addtime").find();
            default = site["name"]
        return default

    def get_site_lists(self, get):
        # self._check_site()
        self.write_site_domains()
        if os.path.exists('/www/server/apache'):
            if not os.path.exists('/usr/local/memcached/bin/memcached'):
                return public.returnMsg(False, '需要memcached,请先到【软件管理】页面安装!')
            if not os.path.exists('/var/run/memcached.pid'):
                return public.returnMsg(False, 'memcached未启动,请先启动!')
        # modc = self.__get_mod(get)
        # if not cache.get('bt_total'):  return modc

        sites = public.M('sites').field('name').order("addtime").select();
        if len(sites) == 0:
            res_data = {
                "status": False,
                "msg": "请先创建站点。"
            }
        else:
            res_site = []
            for site in sites:
                res_site.append(site["name"])

            default_site = self.get_default_site()
            res_data = {
                "status": True,
                "data": res_site,
                "default": default_site
            }
        return res_data

    def get_total_bysite(self, get):
        # self.__read_config()
        # tmp = self.__config['sites'][get.siteName]
        tmp = {}
        tmp['total'] = self.__get_site_total(get.siteName)
        tmp['site_name'] = get.siteName
        get.s_type = 'request'
        tmp['days'] = self.get_site_total_days(get)
        return tmp


    def get_site_total_days(self, get):
        site = self.__get_siteName(get.siteName)
        # s_type = get.s_type
        # types = {
        #     "request": "req",
        # }
        ts = self.init_ts(site)
        start, end = self.get_last_days(30)
        days_sql = "select time/100 as time1 from request_stat " \
        "where time between {} and {} group by time1 order by time1 desc".format(start, end)
        results = ts.query(days_sql)
        data = []
        if type(results) == str:
            return data
        for res in results:
            date = str(res[0])
            try:
                date = self.__timekey2date(date)
                data.append(date)
            except:
                pass
        return data

    def get_site_total_days_old(self, get):
        get.siteName = self.__get_siteName(get.siteName)

        path = self.__plugin_path + '/total/' + get.siteName + '/' + get.s_type;
        data = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'total.json': continue;
            data.append(fname.split('.')[0])

        return sorted(data, reverse=True)

    def get_site_network_all(self, get):
        get.siteName = self.__get_siteName(get.siteName)

        config = self.get_config(get.siteName)
        save_day = config["save_day"]
        all_start, all_end = self.get_query_date("l"+repr(save_day))
        get_total_sql = "select time/100 as time1, sum(length) as length, " \
        "sum(req) as req, sum(uv) as uv, sum(pv) as pv, sum(ip) as ip, " \
        "sum(spider) as spider, sum(status_500) as s500, sum(status_502) as s502, " \
        "sum(status_503) as s503, sum(http_put) as put, sum(http_get) as get, sum(http_post) as post " \
        "from request_stat " \
        "where time between {} and {} " \
        "group by time1;".format(all_start, all_end)
        ts = self.init_ts(get.siteName)
        results = ts.query(get_total_sql)
        data = {}
        # network_days = []
        request_days = []
        data['total_size'] = 0;
        data['total_request'] = 0
        data['days'] = []
        if type(results) == list: 
            for total_day in results:
                # day_net = {}
                # day_net['date'] = self.__timekey2date(total_day[0])
                # network_days.append(day_net)

                day_req = {}
                
                day_req["date"] = self.__timekey2date(total_day[0])
                day_size = self.get_num_value(total_day[1])
                day_req["size"] = day_size

                data['total_size'] += day_size

                day_req['request'] = self.get_num_value(total_day[2])
                day_req['uv'] = self.get_num_value(total_day[3])
                day_req['pv'] = self.get_num_value(total_day[4])
                day_req['ip'] = self.get_num_value(total_day[5])

                day_req['500'] = self.get_num_value(total_day[7])
                day_req['502'] = self.get_num_value(total_day[8])
                day_req['503'] = self.get_num_value(total_day[9])

                day_req['put'] = self.get_num_value(total_day[10])
                day_req['get'] = self.get_num_value(total_day[11])
                day_req['post'] = self.get_num_value(total_day[12])

                data['total_request'] += day_req["request"]
                data["days"].append(day_req)

        # path = self.__plugin_path + '/total/' + get.siteName + '/network';
        # if os.path.exists(path):
        #     for fname in os.listdir(path):
        #         if fname == 'total.json': continue;
        #         day_net = {}
        #         day_net['date'] = fname.split('.')[0]
        #         day_net['size'] = 0
        #         tmp = self.__get_file_json(path + '/' + fname)
        #         for d in tmp.values(): day_net['size'] += d
        #         data['total_size'] += day_net['size']
        #         network_days.append(day_net)

        # data['total_request'] = 0
        # path = self.__plugin_path + '/total/' + get.siteName + '/request';
        # if os.path.exists(path):
        #     for fname in os.listdir(path):
        #         if fname == 'total.json': continue;
        #         day_req = {}
        #         day_req['date'] = fname.split('.')[0]
        #         tmp = self.__get_file_json(path + '/' + fname)
        #         day_req['request'] = 0
        #         day_req['ip'] = 0
        #         day_req['pv'] = 0
        #         day_req['uv'] = 0
        #         day_req['post'] = 0
        #         day_req['get'] = 0
        #         day_req['put'] = 0
        #         day_req['500'] = 0
        #         day_req['502'] = 0
        #         day_req['503'] = 0
        #         for c in tmp.values():
        #             for d in c:
        #                 if re.match("^\d+$", d): day_req['request'] += c[d]
        #                 if 'ip' == d: day_req['ip'] += c['ip']
        #                 if 'pv' == d: day_req['pv'] += c['pv']
        #                 if 'uv' == d: day_req['uv'] += c['uv']
        #                 if 'POST' == d: day_req['post'] += c['POST']
        #                 if 'GET' == d: day_req['get'] += c['GET']
        #                 if 'PUT' == d: day_req['put'] += c['PUT']
        #                 if '500' == d: day_req['500'] += c['500']
        #                 if '503' == d: day_req['503'] += c['503']
        #                 if '502' == d: day_req['502'] += c['502']
        #         data['total_request'] += day_req['request']
        #         request_days.append(day_req)

        # data['days'] = []
        # for request in request_days:
        #     request['size'] = 0;
        #     for s_network in network_days:
        #         if request['date'] == s_network['date']: request['size'] = \
        #         s_network['size']
        #     data['days'].append(request)

        data['days'] = sorted(data['days'], key=lambda x: x['date'],
                              reverse=True);
        return data

    def get_site_total_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        time_key = self.__today2timekey(get.s_day)
        start_date, end_date = self.get_query_date(time_key)
        types = {
            "request": "req",
            "network": "length",
        }
        fields = types[get.s_type]
        fields += ",http_get, http_post"
        select_sql = "select time, {} from request_stat where time between {} and {}"\
            .format(fields, start_date, end_date)
        # print("select sql byday:" + select_sql)
        ts = self.init_ts(get.siteName)
        results = ts.query(select_sql)
        data = []
        if type(results) == list:
            for result in results:
                time_key = str(result[0])
                hour = time_key[len(time_key)-2:]
                value = result[1]
                data.append({"key":hour, "value": value, "GET": result[2], "POST": result[3]})
        
        # filename = self.__plugin_path + '/total/' + get.siteName + '/' + get.s_type + '/' + get.s_day + '.json'
        # if not os.path.exists(filename): return []
        # return self.__sort_json(self.__get_file_json(filename), False)
        return data

    def get_site_total_byspider(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        ts = self.init_ts(get.siteName) 
        columns = ts.query("PRAGMA table_info([{}])".format("spider_stat"))
        fields = []
        for column in columns:
            column_name = column[1]
            if column_name == "time": continue
            fields.append(column_name)
            
        config = self.get_config(get.siteName)
        save_day = config["save_day"]
        all_start, all_end = self.get_query_date("l"+repr(save_day))
        select_all_sql = "select sum(spider) from request_stat where time between {} and {}".format(all_start, all_end)
        all_results = ts.query(select_all_sql)
        data = {}
        data['total_all'] = 0
        if type(all_results) == list:
            data["total_all"] = self.get_num_value(all_results[0][0])

        query_date = time.strftime('%Y%m%d', time.localtime())
        start_date, end_date = self.get_query_date(query_date)
        get_spider_sql = "select time/100 as time1, " + ",".join(fields) + \
        " from spider_stat where time between {} and {} group by time1".format(start_date, end_date)
        results = ts.query(get_spider_sql)
        data['total_day'] = 0
        data['days'] = []
        ts.close()

        if type(results) == list:
            for total_spider in results:
                tmp = {}
                time_key = total_spider[0]
                tmp['date'] = self.__timekey2date(time_key)
                for i, field in enumerate(fields):
                    tmp[field] = total_spider[i+1]
                data['days'].append(tmp)
            data['days'] = sorted(data['days'], key=lambda x: x['date'], reverse=True);
        return data

    def get_site_total_byclient(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        path = self.__plugin_path + '/total/' + get.siteName + '/client';
        data = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'total.json': continue
            filename = path + '/' + fname
            day_data = self.__get_file_json(filename)
            tmp = {}
            tmp['date'] = fname.split('.')[0]
            for s_data in day_data.values():
                for s_key in s_data.keys():
                    if not s_key in tmp:
                        tmp[s_key] = s_data[s_key]
                    else:
                        tmp[s_key] += s_data[s_key]
            data.append(tmp)
        data = sorted(data, key=lambda x: x['date'], reverse=True);
        return data

    def get_site_total_byarea(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        if not 's_day' in get: get.s_day = 'total';
        path = self.__plugin_path + '/total/' + get.siteName + '/area/' + get.s_day + '.json';
        data = {}
        data['date'] = get.s_day
        data['num'] = 0
        data['total'] = []
        if not os.path.exists(path): return data
        day_data = self.__get_file_json(path)
        data['num'] = self.__sum_dict(day_data)
        for s_key in day_data.keys():
            tmp1 = {}
            tmp1['area'] = s_key
            tmp1['num'] = day_data[s_key]
            tmp1['percentage'] = round(
                (float(tmp1['num']) / float(data['num'])) * 100.0, 2)
            data['total'].append(tmp1)
        data['total'] = sorted(data['total'], key=lambda x: x['num'],
                               reverse=True)
        return data

    def __sum_dict(self, data):
        num = 0
        for v in data.values():
            if type(v) == int:
                num += v
            else:
                for d in v.values(): num += d
        return num

    def __sort_json(self, data, dest=True):
        result = []
        for k in data.keys():
            if type(data[k]) == int:
                tmp = {}
                tmp['value'] = data[k]
            else:
                tmp = data[k]
            tmp['key'] = k
            result.append(tmp)
        return sorted(result, key=lambda x: x['key'], reverse=dest)

    def get_site_log_days(self, get):
        srcSiteName = get.siteName
        get.siteName = self.__get_siteName(get.siteName)
        self.__read_config()
        data = {}
        data['log_open'] = self.__config['sites'][srcSiteName]['log_open']
        data['save_day'] = self.__config['sites'][srcSiteName]['save_day']
        path = self.__plugin_path + '/logs/' + get.siteName
        data['days'] = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'error': continue;
            data['days'].append(fname.split('.')[0])
        data['days'] = sorted(data['days'], key=lambda x: x, reverse=True)
        return data

    def remove_site_log_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        if not 'error_log' in get:
            path = s_path + '/' + get.s_day + '.log'
        else:
            path = s_path + '/error/' + get.s_status + '.log'

        if os.path.exists(path): os.remove(path)
        return public.returnMsg(True, '日志清除成功!');

    def remove_site_log(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        public.ExecShell("rm -rf " + s_path)
        return public.returnMsg(True, '日志清除成功!');

    def get_site_log_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        result = {}
        result['total_size'] = 0
        result['size'] = 0
        result['data'] = []
        get.site = get.siteName
        path = s_path + '/logs.db'
        if os.path.exists(path): result['total_size'] = os.path.getsize(path)
        page_size = 10
        get.page_size = page_size
        page = 1
        if 'p' in get:
            page = int(get.p)
            get.page=page
        # if not os.path.exists(s_path): return result
        if not 'error_log' in get:
            if not 's_day' in get: return public.returnMsg(False, '请指定日期!')
            query_date = self.__today2timekey(get.s_day)
            get.query_date = query_date

            results = self.get_site_logs(get)
            # for uname in os.listdir(s_path):
            #     filename = s_path + '/' + uname
            #     if os.path.isdir(filename): continue
            #     result['total_size'] += os.path.getsize(filename)
        else:
            if not 's_status' in get: return public.returnMsg(False, '请指定状态!')
            # s_path += '/error'
            # if not os.path.exists(s_path): return result
            path = s_path + '/' + get.s_status + '.log'
            get.status_code = get.s_status
            results = self.get_site_logs(get)
            # if os.path.exists(path): result['size'] = os.path.getsize(path)
            # for uname in os.listdir(s_path):
            #     filename = s_path + '/' + uname
            #     if os.path.isdir(filename): continue
            #     result['total_size'] += os.path.getsize(filename)
        # try:
        #     import cgi
        #     pyVersion = sys.version_info[0]
        #     num = 10;
        #     if not os.path.exists(path): return [];
        #     p = 1;
        #     if 'p' in get:
        #         p = int(get.p);

        #     start_line = (p - 1) * num;
        #     count = start_line + num;
        #     fp = open(path, 'rb')
        #     buf = ""
        #     fp.seek(-1, 2)
        #     if fp.read(1) == "\n": fp.seek(-1, 2)
        #     data = []
        #     b = True
        #     n = 0;
        #     for i in range(count):
        #         while True:
        #             newline_pos = str.rfind(str(buf), "\n")
        #             pos = fp.tell()
        #             if newline_pos != -1:
        #                 if n >= start_line:
        #                     line = buf[newline_pos + 1:]
        #                     try:
        #                         tmp_data = json.loads(line)
        #                         for i in range(len(tmp_data)): tmp_data[
        #                             i] = cgi.escape(str(tmp_data[i]), True)
        #                         data.append(tmp_data)
        #                     except:
        #                         pass
        #                 buf = buf[:newline_pos]
        #                 n += 1;
        #                 break;
        #             else:
        #                 if pos == 0:
        #                     b = False
        #                     break
        #                 to_read = min(4096, pos)
        #                 fp.seek(-to_read, 1)
        #                 t_buf = fp.read(to_read)
        #                 if pyVersion == 3:
        #                     if type(t_buf) == bytes: t_buf = t_buf.decode(
        #                         'utf-8')
        #                 buf = t_buf + buf
        #                 fp.seek(-to_read, 1)
        #                 if pos - to_read == 0:
        #                     buf = "\n" + buf
        #         if not b: break;
        #     fp.close()
        # except:
        #     data = []
        data = []
        #           0     1   2                4           5         6    7           8            9        10            
        # fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers"
        if results["status"]:
            for line in results["list_data"]:
                # print("error log line:")
                # return public.returnMsg(False, str(line))
                # line = json.loads(line)
                data.append([
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(line["time"]))),
                    line["ip"],
                    get.siteName,
                    line["method"],
                    line["status_code"],
                    line["uri"],
                    line["body_length"],
                    line["referer"],
                    line["user_agent"],
                    line["protocol"]
                ])
        result['data'] = data
        return result

    def __timekey2date(self, timekey):
        date = str(timekey)
        date = date[0:4]+"-"+date[4:6]+"-"+date[6:]
        return date

    def __today2timekey(self, date):
        time_key = date.replace("-", "")
        return time_key

    def __get_site_total(self, siteName, get=None):
        data = {}
        is_red = False
        if not get: get = get_input()
        if hasattr(get, 'today'):
            today = get['today']
        else:
            today_time = time.localtime()
            today = time.strftime('%Y-%m-%d', today_time)
            is_red = True

        data['client'] = 0
        siteName = self.__get_siteName(siteName)
        # spdata = self.__get_file_json(
        #     self.__plugin_path + '/total/' + siteName + '/client/total.json')
        # for c in spdata.values(): data['client'] += c


        # 获取总流量
        config = self.get_config(siteName)
        save_day = config["save_day"]
        all_start, all_end = self.get_query_date("l"+repr(save_day))
        get_total_sql = "select sum(length) as length, sum(req) as req, " \
        "sum(spider) as spider from request_stat where time between {} and {}".format(all_start, all_end)

        ts = self.init_ts(siteName)
        results = ts.query(get_total_sql)
        if type(results) == str:
            data["newwork"] = 0
            data["request"] = 0
            data["spider"] = 0
        else:
            data["network"] = self.get_num_value(results[0][0])
            data["request"] = self.get_num_value(results[0][1])
            data["spider"] = self.get_num_value(results[0][2])

        # 获取实时的请求和流量
        data['req_sec'] = 0
        data['flow_sec'] = 0
        realtime_req_list = self.get_realtime_request(siteName)
        if len(realtime_req_list) > 0:
            data["req_sec"] = self.get_num_value(realtime_req_list[0]["req"])
        else:
            data["req_sec"] = 0

        realtime_traffic_list = self.get_realtime_traffic(siteName)
        if len(realtime_traffic_list) > 0:
            data["flow_rec"] = self.get_num_value(realtime_traffic_list[0]["flow"])
        else:
            data["flow_rec"] = 0
                       
        #  获取今日总流量
        data['day_network'] = 0
        time_key = self.__today2timekey(today)
        start, end = self.get_query_date(time_key)
        get_network_sql = "select sum(length) as length, sum(spider) as spider from request_stat where time between {} and {}".format(start, end)
        day_results = ts.query(get_network_sql)
        # print("site name:"+siteName)
        # print("今日总流量查询结果:"+str(day_results))
        if type(day_results) == list:
            day_network = self.get_num_value(day_results[0][0])
            data['day_network'] = day_network
            day_spider = self.get_num_value(day_results[0][1])
            data["day_spider"] = day_spider


        # path = self.__plugin_path + '/total/' + siteName + '/network/' + today + '.json'
        # if os.path.exists(path):
        #     spdata = self.__get_file_json(path)
        #     for c in spdata.values(): data['day_network'] += c
        # data['request'] = self.__total_request(
        #     self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['day_request'], data['day_ip'], data['day_pv'], data['day_uv'], \
        data['day_post'], data['day_get'], data['day_put'], data['day_500'], \
        data['day_502'], data['day_503'] = self.__total_request(siteName, time_key)

        # data['spider'] = 0

        # spdata = self.__get_file_json(
        #     self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        # for c in spdata.values(): data['spider'] += c

        # data['day_spider'] = 0
        # path = self.__plugin_path + '/total/' + siteName + '/spider/' + today + '.json'
        data['day_spider_arr'] = {}

        table_info = ts.query("PRAGMA table_info([{}])".format("spider_stat"))
        columns = []
        for column in table_info:
            column_name = column[1]
            if column_name == "time": continue
            columns.append(column_name)

        get_spider_sql = "select time, "+",".join(columns) + " from spider_stat where time between {} and {}".format(start, end)
        spider_results = ts.query(get_spider_sql)
        if type(spider_results) == list:
            for spider_line in spider_results:
                time_key = str(spider_line[0])
                hour = time_key[len(time_key)-2:]
                spider_data = {}
                for i, column in enumerate(columns):
                    if column == "s360": column = "360"
                    spider_data[column] = spider_line[i+1] 
                data['day_spider_arr'][hour] = spider_data

        # if os.path.exists(path):
        #     spdata = self.__get_file_json(path)
        #     data['day_spider_arr'] = spdata
        #     for c in spdata.values():
        #         for d in c.values(): data['day_spider'] += d

        ts.close()

        if is_red:
            try:
                data['7day_total'] = []
                for i in range(6):
                    get.today = (datetime.date.today() + datetime.timedelta(
                        ~(i + 1) + 1)).strftime("%Y-%m-%d")
                    tmp = self.__get_site_total(siteName, get)
                    tmp['date'] = get.today
                    data['7day_total'].insert(0, tmp)
            except:
                pass
        return data

    def __get_site_total_old(self, siteName, get=None):
        data = {}
        is_red = False
        if not get: get = get_input()
        if hasattr(get, 'today'):
            today = get['today']
        else:
            today_time = time.localtime()
            today = time.strftime('%Y-%m-%d', today_time)
            is_red = True

        data['client'] = 0
        siteName = self.__get_siteName(siteName)
        spdata = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/client/total.json')
        for c in spdata.values(): data['client'] += c

        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/network/total.json',
            0)
        req_sec_file = self.__plugin_path + '/total/' + siteName + '/req_sec.json'
        data['req_sec'] = 0
        data['flow_sec'] = 0
        if os.path.exists(req_sec_file):
            if time.time() - os.stat(req_sec_file).st_mtime < 10:
                data['req_sec'] = self.__get_file_json(req_sec_file, 0)
                data['flow_sec'] = self.__get_file_json(
                    self.__plugin_path + '/total/' + siteName + '/flow_sec.json',
                    0)
        data['day_network'] = 0
        path = self.__plugin_path + '/total/' + siteName + '/network/' + today + '.json'
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            for c in spdata.values(): data['day_network'] += c
        data['request'] = self.__total_request(
            self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['day_request'], data['day_ip'], data['day_pv'], data['day_uv'], \
        data['day_post'], data['day_get'], data['day_put'], data['day_500'], \
        data['day_502'], data['day_503'] = self.__total_request(
            self.__plugin_path + '/total/' + siteName + '/request/' + today + '.json')
        data['spider'] = 0

        spdata = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        for c in spdata.values(): data['spider'] += c

        data['day_spider'] = 0
        path = self.__plugin_path + '/total/' + siteName + '/spider/' + today + '.json'
        data['day_spider_arr'] = {}
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            data['day_spider_arr'] = spdata
            for c in spdata.values():
                for d in c.values(): data['day_spider'] += d
        if is_red:
            try:
                data['7day_total'] = []
                for i in range(6):
                    get.today = (datetime.date.today() + datetime.timedelta(
                        ~(i + 1) + 1)).strftime("%Y-%m-%d")
                    tmp = self.__get_site_total(siteName, get)
                    tmp['date'] = get.today
                    data['7day_total'].insert(0, tmp)
            except:
                pass
        return data

    def __get_site_total_bysite(self, siteName):
        data = {}
        siteName = self.__get_siteName(siteName)
        data['client'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/client/total.json')
        data['area'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/area/total.json')
        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/network/total.json',
            0)
        data['request'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['spider'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        return data

    def __get_siteName(self, siteName):
        db_file = self.__plugin_path + '/total/logs/' + siteName + '/logs.db'
        if os.path.isfile(db_file): return siteName

        cache_key = "SITE_NAME"+"_"+siteName
        if cache.get(cache_key):
            return cache.get(cache_key)

        pid = public.M('sites').where('name=?', (siteName,)).getField('id');
        if not pid: 
            cache.set(cache_key, siteName)
            return siteName

        domains = public.M('domain').where('pid=?', (pid,)).field(
            'name').select()
        for domain in domains:
            db_file = self.__plugin_path + '/total/logs/' + siteName + '/logs.db'
            if os.path.isfile(db_file): 
                siteName = domain['name']
                break
        cache.set(cache_key, siteName.replace('_', '.'))
        return cache.get(cache_key)

    def write_lua_config(self, config=None):
        if not config:
            config = json.loads(public.readFile("/www/server/total/config.json"))
        lua_config = LuaMaker.makeLuaTable(config)
        lua_config = "return " + lua_config
        public.WriteFile("/www/server/total/total_config.lua", lua_config)

    def write_site_domains(self):
        sites = public.M('sites').field('name,id').select();
        my_domains = []
        for my_site in sites:
            tmp = {}
            tmp['name'] = my_site['name']
            tmp_domains = public.M('domain').where('pid=?',
                                                   (my_site['id'],)).field(
                'name').select()
            tmp['domains'] = []
            for domain in tmp_domains:
                tmp['domains'].append(domain['name'])
            binding_domains = public.M('binding').where('pid=?',
                                                        (my_site['id'],)).field(
                'domain').select()
            for domain in binding_domains:
                tmp['domains'].append(domain['domain'])
            my_domains.append(tmp)
        public.writeFile(self.__plugin_path + '/domains.json',
                         json.dumps(my_domains))
        config_domains = LuaMaker.makeLuaTable(my_domains)
        domains_str = "return " + config_domains
        public.WriteFile("/www/server/total/domains.lua", domains_str)
        return my_domains

    def get_num_value(self, value):
        if value is None:
            return 0
        return value

    def __total_request(self, site, query_date, get_total=False):
        start_time_key, end_time_key = self.get_query_date(query_date)

        select_request_sql  = "select " \
        "sum(req) as req, sum(uv) as uv, sum(pv) as pv, sum(ip) as ip, " \
        "sum(spider) as spider, sum(status_500) as s500, sum(status_502) as s502, " \
        "sum(status_503) as s503, sum(http_put) as put, sum(http_get) as get, sum(http_post) as post " \
        "from request_stat " \
        "where time between {} and {}".format(start_time_key, end_time_key)

        ts = self.init_ts(site)
        results = ts.query(select_request_sql)
        # print("total request result:"+str(results))
        day_request = 0
        day_ip = 0
        day_pv = 0
        day_uv = 0
        day_post = 0
        day_get = 0
        day_put = 0
        day_500 = 0
        day_503 = 0
        day_502 = 0
        if type(results) == list:
            day_request = self.get_num_value(results[0][0])
            if get_total:
                ts.close()
                return day_request
            day_uv = self.get_num_value(results[0][1])
            day_pv = self.get_num_value(results[0][2])
            day_ip = self.get_num_value(results[0][3])

            day_500 = self.get_num_value(results[0][5])
            day_502 = self.get_num_value(results[0][6])
            day_503 = self.get_num_value(results[0][7])

            day_put = self.get_num_value(results[0][8])
            day_get = self.get_num_value(results[0][9])
            day_post = self.get_num_value(results[0][10])
        
        ts.close()
        return day_request, day_ip, day_pv, day_uv, day_post, day_get, day_put, day_500, day_502, day_503
        
    def __total_request_old(self, path):
        day_request = 0
        day_ip = 0
        day_pv = 0
        day_uv = 0
        day_post = 0
        day_get = 0
        day_put = 0
        day_500 = 0
        day_503 = 0
        day_502 = 0
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            if path.find('total.json') != -1:
                for c in spdata:
                    if re.match("^\d+$", c): day_request += spdata[c]
                return day_request

            for c in spdata.values():
                for d in c:
                    if re.match("^\d+$", d): day_request += c[d]
                    if 'ip' == d: day_ip += c['ip']
                    if 'pv' == d: day_pv += c['pv']
                    if 'uv' == d: day_uv += c['uv']
                    if 'POST' == d: day_post += c['POST']
                    if 'GET' == d: day_get += c['GET']
                    if 'PUT' == d: day_put += c['PUT']
                    if '500' == d: day_500 += c['500']
                    if '503' == d: day_503 += c['503']
                    if '502' == d: day_502 += c['502']

        if path.find('total.json') != -1: return day_request
        return day_request, day_ip, day_pv, day_uv, day_post, day_get, day_put, day_500, day_502, day_503

    def __remove_log_file(self, siteName):
        siteName = self.__get_siteName(siteName)
        path = self.__plugin_path + '/total/' + siteName
        if os.path.exists(path): public.ExecShell("rm -rf " + path)
        path = self.__plugin_path + '/logs/' + siteName
        if os.path.exists(path): public.ExecShell("rm -rf " + path)

    def __get_file_json(self, filename, defaultv={}):
        try:
            if not os.path.exists(filename): return defaultv;
            return json.loads(public.readFile(filename))
        except:
            os.remove(filename)
            return defaultv

    def __write_config(self):
        public.writeFile(self.__plugin_path + '/config.json',
                         json.dumps(self.__config))
        public.serviceReload();

    def __read_config(self, site="global"):
        if self.__config: return True
        data = public.readFile(self.__plugin_path + '/config.json')
        self.__config = json.loads(data)

    def get_test(self, get):
        return self.__read_config();

    def __write_logs(self, logstr):
        public.WriteLog('网站监控', logstr)

    def return_file(self, file):
        for root, dirs, files in os.walk(file):
            return files

    def get_ip_total(self, get):
        server_name = get.server_name.strip()
        day = get.day.strip()
        path = '/www/server/total/total/' + server_name + '/ip_total/' + day
        if not os.path.exists(path): return public.returnMsg(False, '无日志')
        file_data = self.return_file(path)
        result = []
        for i in file_data:
            try:
                tmp = {}
                tmp['ip'] = i.split('.json')[0]
                tmp['totla'] = json.loads(public.ReadFile(path + '/' + i))[
                    'totla']
                result.append(tmp)
            except:
                continue
        return result

    def migrate_total(self, get):
        import threading
        migrate_thread = threading.Thread(target=total_migrate().migrate_total)
        migrate_thread.setDaemon(True)
        migrate_thread.start()
        return public.returnMsg(True, "正在迁移中，请稍后。")

    def get_migrate_status(self, get):
        tm = total_migrate()
        res = tm.get_migrate_status()
        status = True if res["status"] == "completed" else False
        if not status:
            check_path = "/www/server/total/total"
            if not os.path.isdir(check_path) or public.get_path_size(
                    check_path) == 0:
                tm.set_migrate_status("completed")
                return tm.get_migrate_status()
        return res

    def get_site_settings(self, site):
        """获取站点配置"""

        config_path = "/www/server/total/config.json"
        config = self.__get_file_json(config_path)
        frontend_config = self.__read_frontend_config()

        res_config = {}
        if site not in config.keys():
            res_config = config["global"]
        else:
            res_config = config[site]

        for k, v in config["global"].items():
            if k not in res_config:
                res_config[k] = v
        res_config["default_site"] = self.get_default_site()
        return res_config

    def get_settings_info(self, get):
        """获取站点信息 
        适用插件前端调用"""
        site = None
        if "site" in get:
            site = get.site.lower()
        if not site:
            return public.returnMsg(False, "请选择站点。")

        settings_info = self.get_site_settings(site)
        for k, v in settings_info.items():
            if type(v) == list:
                _v = [str(x) for x in v]
                settings_info[k] = ",".join(_v)
        return settings_info

    def set_settings(self, get):
        """修改配置文件"""
        site = None
        if "site" in get:
            site = get.site.lower().strip()
        if not site:
            return public.returnMsg(False, "请选择站点。")
        targets = []
        if site != "global":
            if site.find(",") < 0:
                targets.append(site)
            else:
                targets = [x for x in site.split(",") if x.strip()]
        sync = False
        if "sync" in get:
            sync = True if get.sync == "true" else False

        new_config = {}
        monitor = None
        if "monitor" in get:
            monitor = True if get.monitor == "true" else False
            new_config["monitor"] = monitor
        default_site = None
        if "default_site" in get:
            default_site = get.default_site
            self.set_default_site(default_site)
        auto_refresh = None
        if "autorefresh" in get:
            auto_refresh = True if get.autorefresh == "true" else False
            new_config["autorefresh"] = auto_refresh
        refresh_interval = 3
        if "refresh_interval" in get:
            refresh_interval = int(get.refresh_interval)
            if refresh_interval < 3:
                refresh_interval = 3
            new_config["refresh_interval"] = refresh_interval
        cdn = True
        if "cdn" in get:
            cdn = True if get.cdn == "true" else False
            new_config["cdn"] = cdn
        cdn_headers = None
        if "cdn_headers" in get:
            cdn_headers = get.cdn_headers
            if cdn_headers == "null":
                cdn_headers = []
            else:
                cdn_headers = [x.strip() for x in cdn_headers.split(",")]
            new_config["cdn_headers"] = cdn_headers

        exclude_extension = None
        if "exclude_extension" in get:
            exclude_extension = get.exclude_extension
            if exclude_extension == "null":
                exclude_extension = []
            else:
                exclude_extension = [x.strip() for x in
                                     exclude_extension.split(",")]
            new_config["exclude_extension"] = exclude_extension
        exclude_status = []
        if "exclude_status" in get:
            exclude_status = get.exclude_status
            if exclude_status == "null":
                exclude_status = []
            else:
                exclude_status = [x.strip() for x in exclude_status.split(",")]
            new_config["exclude_status"] = exclude_status
        save_day = 180
        if "save_day" in get:
            save_day = int(get.save_day)
            new_config["save_day"] = save_day

        config_path = "/www/server/total/config.json"
        config_data = self.__get_file_json(config_path)
        if site != "global":
            for target_site in targets:
                site_config = {}
                if target_site in config_data.keys():
                    site_config = config_data[target_site]
                if new_config:
                    site_config.update(new_config)
                    config_data[target_site] = site_config
        else:
            if new_config:
                config = config_data["global"]
                config.update(new_config)
                config_data["global"] = config
                self.set_monitor_status(config["monitor"])
        public.writeFile(config_path, json.dumps(config_data))
        self.write_lua_config(config_data)
        public.serviceReload()
        return public.returnMsg(True, "配置修改成功。")

    def set_monitor_status(self, status):
        if status == True:
            if os.path.isfile(self.close_file):
                os.remove(self.close_file)
            if not os.path.isfile("/www/server/panel/vhost/nginx/total.conf"):
                os.system("cp /www/server/total/total_nginx.conf /www/server/panel/vhost/nginx/total.conf")
            if not os.path.isfile("/www/server/panel/vhost/apache/total.conf"):
                os.system("cp /www/server/total/total_httpd.conf /www/server/panel/vhost/apache/total.conf")
        else:
            public.WriteFile(self.close_file, "closing")
            os.system("rm -f /www/server/panel/vhost/nginx/total.conf")
            os.system("rm -f /www/server/panel/vhost/apache/total.conf")

    def sync_settings(self, get):
        """同步站点配置"""
        profile = None
        if "profile" in get:
            profile = get.profile.lower().strip()
        tosites = None
        if "tosites" in get:
            tosites = get.tosites.strip()
        targets = []
        if tosites != "all":
            if tosites.find(",") < 0:
                targets.append(tosites)
            else:
                targets = [x for x in tosites.split(",") if x.strip()]
        else:
            tosites = public.M('sites').field('name').order("addtime").select();
            targets = [x["name"] for x in tosites]

        new_config = {}
        monitor = None
        if "monitor" in get:
            monitor = True if get.monitor == "true" else False
            new_config["monitor"] = monitor
        auto_refresh = None
        if "autorefresh" in get:
            auto_refresh = True if get.autorefresh == "true" else False
            new_config["autorefresh"] = auto_refresh
        refresh_interval = 3
        if "refresh_interval" in get:
            refresh_interval = int(get.refresh_interval)
            if refresh_interval < 3:
                refresh_interval = 3
            new_config["refresh_interval"] = refresh_interval
        # cdn = True
        # if "cdn" in get:
        #     cdn = True if get.cdn=="true" else False
        #     new_config["cdn"] = cdn
        cdn_headers = None
        if "cdn_headers" in get:
            cdn_headers = get.cdn_headers
            if cdn_headers == "null":
                cdn_headers = []
            else:
                cdn_headers = [x.strip() for x in cdn_headers.split(",")]
            new_config["cdn_headers"] = cdn_headers

        exclude_extension = None
        if "exclude_extension" in get:
            exclude_extension = get.exclude_extension
            if exclude_extension == "null":
                exclude_extension = []
            else:
                exclude_extension = [x.strip() for x in
                                     exclude_extension.split(",")]
            new_config["exclude_extension"] = exclude_extension
        exclude_status = []
        if "exclude_status" in get:
            exclude_status = get.exclude_status
            if exclude_status == "null":
                exclude_status = []
            else:
                exclude_status = [x.strip() for x in exclude_status.split(",")]
            new_config["exclude_status"] = exclude_status
        save_day = 180
        if "save_day" in get:
            save_day = int(get.save_day)
            new_config["save_day"] = save_day

        # print("Update new config:")
        # print(new_config)

        # print("Target sites:")
        # print(targets)

        # print("Profile:")
        # print(profile)

        config_path = "/www/server/total/config.json"
        config_data = self.__get_file_json(config_path)
        # 保存站点配置
        current_config = {}
        if profile in config_data.keys():
            current_config = config_data[profile]
        current_config.update(new_config)
        config_data[profile] = current_config

        # 同步配置
        for target_site in targets:
            site_profile = {}
            if target_site in config_data.keys():
                site_profile = config_data[target_site]

            if new_config:
                site_profile.update(new_config)
                config_data[target_site] = site_profile

        public.writeFile(config_path, json.dumps(config_data))
        lua_config = LuaMaker.makeLuaTable(config_data)
        lua_config = "return " + lua_config
        public.WriteFile("/www/server/total/total_config.lua", lua_config)
        public.serviceReload()
        return public.returnMsg(True, "配置同步成功。")